import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/health")({
  server: {
    handlers: {
      GET: async () => {
        return Response.json({
          status: "ok",
          service: "butler-ai-nexus",
          timestamp: new Date().toISOString(),
          uptime: process.uptime?.() ?? 0,
        });
      },
    },
  },
});
